import React from 'react';

function App() {
  return <IPhoneXXS11Pro3 {...iPhoneXXS11Pro3Data} />;
}

export default App;

function IPhoneXXS11Pro3(props) {
  const {
    ellipse1,
    text20,
    path10242,
    path10243,
    scrollGroup1Props,
    moreScreenProps,
    group8124Props,
    group8125Props,
    group81252Props,
    group8129Props,
    group8129Props2,
    group8134Props,
  } = props;

  return (
    <div class="container-center-horizontal">
      <div className="iphone-x-xs-11-pro-3 screen">
        <div className="overlap-group">
          <ScrollGroup1
            overlapGroup1={scrollGroup1Props.overlapGroup1}
            path10208={scrollGroup1Props.path10208}
            layer812Props={scrollGroup1Props.layer812Props}
            layer8122Props={scrollGroup1Props.layer8122Props}
          />
          <img className="ellipse-1" src={ellipse1} />
          <p className="text-1 helveticaneue-regular-normal-white-12px">{text20}</p>
          <img className="path-10242" src={path10242} />
          <img className="path-10243" src={path10243} />
          <MoreScreen statusBar2Props={moreScreenProps.statusBar2Props} />
          <Group8124 image4={group8124Props.image4} scrollGroup4Props={group8124Props.scrollGroup4Props} />
          <Group8125 image3={group8125Props.image3} scrollGroup4Props={group8125Props.scrollGroup4Props} />
          <Group8125
            image3={group81252Props.image3}
            scrollGroup4Props={group81252Props.scrollGroup4Props}
            className="group-8126"
          />
          <Group8129
            path2718={group8129Props.path2718}
            path10249={group8129Props.path10249}
            path10250={group8129Props.path10250}
            path2719={group8129Props.path2719}
          />
          <Group8129
            path2718={group8129Props2.path2718}
            path10249={group8129Props2.path10249}
            path10250={group8129Props2.path10250}
            path2719={group8129Props2.path2719}
          />
          <Group8134
            address={group8134Props.address}
            ilUsa={group8134Props.ilUsa}
            address2={group8134Props.address2}
            ilUsa2={group8134Props.ilUsa2}
          />
        </div>
      </div>
    </div>
  );
}


function ScrollGroup1(props) {
  const { overlapGroup1, path10208, layer812Props, layer8122Props } = props;

  return (
    <div className="scroll-group-3">
      <div className="overlap-group1" style={{ backgroundImage: `url(${overlapGroup1})` }}>
        <div className="group-8116">
          <div className="overlap-group2">
            <div className="ellipse-84"></div>
            <div className="ellipse-85 border-2px-white"></div>
          </div>
        </div>
        <img className="path-10239" src={path10208} />
        <div className="ellipse-86"></div>
        <div className="ellipse-87"></div>
        <Layer812 src={layer812Props.src} />
        <Layer812 src={layer8122Props.src} className="layer812" />
      </div>
    </div>
  );
}


function Layer812(props) {
  const { src, className } = props;

  return (
    <div className={`layer812-1 ${className || ""}`}>
      <img className="path-10240" src={src} />
    </div>
  );
}


function MoreScreen(props) {
  const { statusBar2Props } = props;

  return (
    <div className="more-screen">
      <StatusBar2
        path2707={statusBar2Props.path2707}
        path2708={statusBar2Props.path2708}
        path2709={statusBar2Props.path2709}
        path2710={statusBar2Props.path2710}
        path2711={statusBar2Props.path2711}
        path2712={statusBar2Props.path2712}
        iconsProps={statusBar2Props.iconsProps}
      />
      <div className="rectangle-183"></div>
    </div>
  );
}


function StatusBar2(props) {
  const { path2707, path2708, path2709, path2710, path2711, path2712, iconsProps } = props;

  return (
    <div className="status-bar">
      <div className="time">
        <img className="path-2707" src={path2707} />
        <img className="path-2708" src={path2708} />
        <img className="path-2709" src={path2709} />
        <img className="path-2710" src={path2710} />
        <img className="path-2711" src={path2711} />
        <img className="path-2712" src={path2712} />
      </div>
      <Icons
        group865={iconsProps.group865}
        group863={iconsProps.group863}
        overlapGroup2={iconsProps.overlapGroup2}
        rectangle179={iconsProps.rectangle179}
        path2716={iconsProps.path2716}
      />
    </div>
  );
}


function Icons(props) {
  const { group865, group863, overlapGroup2, rectangle179, path2716 } = props;

  return (
    <div className="icons">
      <div className="group-865" style={{ backgroundImage: `url(${group865})` }}></div>
      <div className="group-863" style={{ backgroundImage: `url(${group863})` }}></div>
      <div className="group-868">
        <div className="overlap-group1-1" style={{ backgroundImage: `url(${overlapGroup2})` }}>
          <img className="rectangle-179" src={rectangle179} />
        </div>
        <img className="path-2716" src={path2716} />
      </div>
    </div>
  );
}


function Group8124(props) {
  const { image4, scrollGroup4Props } = props;

  return (
    <div className="group-8124">
      <div className="overlap-group3">
        <ScrollGroup4 express={scrollGroup4Props.express} address={scrollGroup4Props.address} />
        <div className="ellipse-88"></div>
        <img className="image-4" src={image4} />
      </div>
    </div>
  );
}


function ScrollGroup4(props) {
  const { express, address } = props;

  return (
    <div className="scroll-group-4-1">
      <div className="group-8123">
        <div className="express helveticaneue-bold-comet-17px">{express}</div>
        <p className="address helveticaneue-regular-normal-slimy-green-14px">{address}</p>
      </div>
    </div>
  );
}


function Group8125(props) {
  const { image3, scrollGroup4Props, className } = props;

  return (
    <div className={`group-8125 ${className || ""}`}>
      <div className="overlap-group4">
        <ScrollGroup4 express={scrollGroup4Props.express} address={scrollGroup4Props.address} />
        <div className="ellipse-88-1"></div>
        <img className="image-3" src={image3} />
      </div>
    </div>
  );
}


function Group8129(props) {
  const { path2718, path10249, path10250, path2719 } = props;

  return (
    <div className="group-8131 border-1px-dove-gray">
      <img className="path-2718" src={path2718} />
      <img className="path-" src={path10249} />
      <img className="path-" src={path10250} />
      <img className="path-" src={path2719} />
    </div>
  );
}


function Group8134(props) {
  const { address, ilUsa, address2, ilUsa2 } = props;

  return (
    <div className="group-8134">
      <div className="overlap-group7">
        <div className="address-1 helveticaneue-bold-white-17px">{address}</div>
        <div className="il-usa helveticaneue-regular-normal-white-12px">{ilUsa}</div>
      </div>
      <div className="overlap-group6">
        <div className="address-2 helveticaneue-bold-white-17px">{address2}</div>
        <div className="il-usa-1 helveticaneue-regular-normal-white-12px">{ilUsa2}</div>
      </div>
    </div>
  );
}

const layer812Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10209@1x.png",
};

const layer8122Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10209@1x.png",
};

const scrollGroup1Data = {
    overlapGroup1: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/image-5@1x.png",
    path10208: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10208@1x.png",
    layer812Props: layer812Data,
    layer8122Props: layer8122Data,
};

const iconsData = {
    group865: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2714-10@1x.png",
    group863: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2713-10@1x.png",
    overlapGroup2: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2715-10@1x.png",
    rectangle179: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/rectangle-179-10@1x.png",
    path2716: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2716-10@1x.png",
};

const statusBar2Data = {
    path2707: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2707-10@1x.png",
    path2708: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2708-10@1x.png",
    path2709: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2709-10@1x.png",
    path2710: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2710-10@1x.png",
    path2711: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2711-10@1x.png",
    path2712: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2712-10@1x.png",
    iconsProps: iconsData,
};

const moreScreenData = {
    statusBar2Props: statusBar2Data,
};

const scrollGroup4Data = {
    express: "Express",
    address: "20 Minute / 6.0 $",
};

const group8124Data = {
    image4: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/image-4-1@1x.png",
    scrollGroup4Props: scrollGroup4Data,
};

const scrollGroup42Data = {
    express: "Normal",
    address: "45 Minute / 3.0 $",
};

const group8125Data = {
    image3: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/image-3-1@1x.png",
    scrollGroup4Props: scrollGroup42Data,
};

const scrollGroup43Data = {
    express: "Slow",
    address: "2 Hours    / 1.5 $",
};

const group81252Data = {
    image3: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/image-3-1@1x.png",
    scrollGroup4Props: scrollGroup43Data,
};

const group8129Data = {
    path2718: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10249-1@1x.png",
    path10249: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10249-1@1x.png",
    path10250: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10249-1@1x.png",
    path2719: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10249-1@1x.png",
};

const group81292Data = {
    path2718: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10249-1@1x.png",
    path10249: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10249-1@1x.png",
    path10250: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10249-1@1x.png",
    path2719: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10249-1@1x.png",
};

const group8134Data = {
    address: "915 W Marketview Dr, Champaign",
    ilUsa: "IL, USA",
    address2: "14 E Anthony Dr, Unit A, Champaign",
    ilUsa2: "IL, USA",
};

const iPhoneXXS11Pro3Data = {
    ellipse1: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/ellipse-1-1@1x.png",
    text20: "Santo Marina, San Francisco, CA USA",
    path10242: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10211@1x.png",
    path10243: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10211@1x.png",
    scrollGroup1Props: scrollGroup1Data,
    moreScreenProps: moreScreenData,
    group8124Props: group8124Data,
    group8125Props: group8125Data,
    group81252Props: group81252Data,
    group8129Props: group8129Data,
    group8129Props2: group81292Data,
    group8134Props: group8134Data,
};

