import React from 'react';

function App() {
  return (
    <X09
      image4="https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/image-4@1x.png"
      fastDelivery="Fast Delivery"
      text15="Fast delivery to your home, office wherever you are"
      statusBarProps={x09Data.statusBarProps}
      sendButtonProps={x09Data.sendButtonProps}
    />
  );
}

export default App;

function X09(props) {
  const { image4, fastDelivery, text15, statusBarProps, sendButtonProps } = props;

  return (
    <div class="container-center-horizontal">
      <div className="x09 screen">
        <StatusBar
          path2707={statusBarProps.path2707}
          path2708={statusBarProps.path2708}
          path2709={statusBarProps.path2709}
          path2710={statusBarProps.path2710}
          path2711={statusBarProps.path2711}
          path2712={statusBarProps.path2712}
          iconsProps={statusBarProps.iconsProps}
        />
        <img className="image-4" src={image4} />
        <SliderIndicators />
        <h1 className="title metropolis-extra-bold-gravel-28px">{fastDelivery}</h1>
        <p className="text-1 metropolis-medium-concord-13px">{text15}</p>
        <SendButton>{sendButtonProps.children}</SendButton>
        <div className="rectangle-183"></div>
      </div>
    </div>
  );
}


function StatusBar(props) {
  const { path2707, path2708, path2709, path2710, path2711, path2712, iconsProps } = props;

  return (
    <div className="status-bar">
      <div className="time">
        <img className="path-2707" src={path2707} />
        <img className="path-2708" src={path2708} />
        <img className="path-2709" src={path2709} />
        <img className="path-2710" src={path2710} />
        <img className="path-2711" src={path2711} />
        <img className="path-2712" src={path2712} />
      </div>
      <Icons
        group865={iconsProps.group865}
        group863={iconsProps.group863}
        overlapGroup2={iconsProps.overlapGroup2}
        rectangle179={iconsProps.rectangle179}
        path2716={iconsProps.path2716}
      />
    </div>
  );
}


function Icons(props) {
  const { group865, group863, overlapGroup2, rectangle179, path2716 } = props;

  return (
    <div className="icons">
      <div className="group-865" style={{ backgroundImage: `url(${group865})` }}></div>
      <div className="group-863" style={{ backgroundImage: `url(${group863})` }}></div>
      <div className="group-868">
        <div className="overlap-group" style={{ backgroundImage: `url(${overlapGroup2})` }}>
          <img className="rectangle-179" src={rectangle179} />
        </div>
        <img className="path-2716" src={path2716} />
      </div>
    </div>
  );
}


function SliderIndicators() {
  return (
    <div className="slider-indicators">
      <div className="ellipse-1"></div>
      <div className="ellipse-2"></div>
      <div className="ellipse-3"></div>
    </div>
  );
}


function SendButton(props) {
  const { children } = props;

  return (
    <div className="send-button">
      <div className="next metropolis-bold-white-16px">{children}</div>
    </div>
  );
}

const iconsData = {
    group865: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2714-10@1x.png",
    group863: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2713-10@1x.png",
    overlapGroup2: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2715-10@1x.png",
    rectangle179: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/rectangle-179-10@1x.png",
    path2716: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2716-10@1x.png",
};

const statusBarData = {
    path2707: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2707-10@1x.png",
    path2708: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2708-10@1x.png",
    path2709: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2709-10@1x.png",
    path2710: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2710-10@1x.png",
    path2711: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2711-1@1x.png",
    path2712: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2712-10@1x.png",
    iconsProps: iconsData,
};

const sendButtonData = {
    children: "Next",
};

const x09Data = {
    statusBarProps: statusBarData,
    sendButtonProps: sendButtonData,
};

