import React from 'react';

function App() {
  return <X03 {...x03Data} />;
}

export default App;

function X03(props) {
  const {
    login,
    text3,
    text1,
    orLoginWith,
    facebookLetterLogo,
    loginWithFacebook,
    group2169,
    group2167,
    loginWithGoogle,
    spanText,
    spanText2,
    statusBarProps,
    textFieldProps,
    textField2Props,
    loginButtonProps,
  } = props;

  return (
    <div class="container-center-horizontal">
      <div className="x03 screen">
        <StatusBar
          path2707={statusBarProps.path2707}
          path2708={statusBarProps.path2708}
          path2709={statusBarProps.path2709}
          path2710={statusBarProps.path2710}
          path2711={statusBarProps.path2711}
          path2712={statusBarProps.path2712}
          iconsProps={statusBarProps.iconsProps}
        />
        <h1 className="title">{login}</h1>
        <p className="text-3 metropolis-medium-concord-14px">{text3}</p>
        <TextField>{textFieldProps.children}</TextField>
        <TextField className="text-field">{textField2Props.children}</TextField>
        <LoginButton>{loginButtonProps.children}</LoginButton>
        <div className="text-1 metropolis-medium-concord-14px">{text1}</div>
        <div className="or-login-with metropolis-medium-concord-14px">{orLoginWith}</div>
        <div className="facebooklogin">
          <div className="facebook-letter-logo" style={{ backgroundImage: `url(${facebookLetterLogo})` }}></div>
          <div className="login-with-facebook metropolis-medium-white-12px">{loginWithFacebook}</div>
        </div>
        <div className="googlelogin">
          <div className="google-plus-logo">
            <div className="group-2169" style={{ backgroundImage: `url(${group2169})` }}></div>
            <div className="group-2167" style={{ backgroundImage: `url(${group2167})` }}></div>
          </div>
          <div className="login-with-google metropolis-medium-white-12px">{loginWithGoogle}</div>
        </div>
        <p className="text-2 metropolis-bold-nile-blue-14px">
          <span className="span metropolis-medium-concord-14px">{spanText}</span>
          <span className="span metropolis-bold-nile-blue-14px-2">{spanText2}</span>
        </p>
        <div className="rectangle-183"></div>
      </div>
    </div>
  );
}


function StatusBar(props) {
  const { path2707, path2708, path2709, path2710, path2711, path2712, iconsProps } = props;

  return (
    <div className="status-bar">
      <div className="time">
        <img className="path-2707" src={path2707} />
        <img className="path-2708" src={path2708} />
        <img className="path-2709" src={path2709} />
        <img className="path-2710" src={path2710} />
        <img className="path-2711" src={path2711} />
        <img className="path-2712" src={path2712} />
      </div>
      <Icons
        group865={iconsProps.group865}
        group863={iconsProps.group863}
        overlapGroup2={iconsProps.overlapGroup2}
        rectangle179={iconsProps.rectangle179}
        path2716={iconsProps.path2716}
      />
    </div>
  );
}


function Icons(props) {
  const { group865, group863, overlapGroup2, rectangle179, path2716 } = props;

  return (
    <div className="icons">
      <div className="group-865" style={{ backgroundImage: `url(${group865})` }}></div>
      <div className="group-863" style={{ backgroundImage: `url(${group863})` }}></div>
      <div className="group-868">
        <div className="overlap-group" style={{ backgroundImage: `url(${overlapGroup2})` }}>
          <img className="rectangle-179" src={rectangle179} />
        </div>
        <img className="path-2716" src={path2716} />
      </div>
    </div>
  );
}


function TextField(props) {
  const { children, className } = props;

  return (
    <div className={`text-field-1 ${className || ""}`}>
      <div className="your-email metropolis-regular-normal-pink-swan-14px">{children}</div>
    </div>
  );
}


function LoginButton(props) {
  const { children } = props;

  return (
    <div className="login-button">
      <div className="login metropolis-bold-white-16px">{children}</div>
    </div>
  );
}

const iconsData = {
    group865: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2714-10@1x.png",
    group863: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2713-10@1x.png",
    overlapGroup2: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2715-10@1x.png",
    rectangle179: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/rectangle-179-10@1x.png",
    path2716: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2716-10@1x.png",
};

const statusBarData = {
    path2707: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2707-10@1x.png",
    path2708: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2708-10@1x.png",
    path2709: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2709-10@1x.png",
    path2710: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2710-10@1x.png",
    path2711: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2711-1@1x.png",
    path2712: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2712-10@1x.png",
    iconsProps: iconsData,
};

const textFieldData = {
    children: "Your Email",
};

const textField2Data = {
    children: "Password",
};

const loginButtonData = {
    children: "Login",
};

const x03Data = {
    login: "Login",
    text3: "Add your details to login",
    text1: "Forgot your password?",
    orLoginWith: "or Login With",
    facebookLetterLogo: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/facebook@1x.png",
    loginWithFacebook: "Login with Facebook",
    group2169: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-1290@1x.png",
    group2167: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-1289@1x.png",
    loginWithGoogle: "Login with Google",
    spanText: "Don't have an Account? ",
    spanText2: "Sign Up",
    statusBarProps: statusBarData,
    textFieldProps: textFieldData,
    textField2Props: textField2Data,
    loginButtonProps: loginButtonData,
};

