import React from 'react';

function App() {
  return <IPhoneXXS11Pro2 {...iPhoneXXS11Pro2Data} />;
}

export default App;

function IPhoneXXS11Pro2(props) {
  const {
    ellipse1,
    path10237,
    path10238,
    parcelInformation,
    text19,
    insurance,
    line90,
    line91,
    add,
    layer812Props,
    scrollGroup1Props,
    statusBar2Props,
    textFieldProps,
    textField2Props,
    loginButtonProps,
    group8129Props,
  } = props;

  return (
    <div class="container-center-horizontal">
      <div className="iphone-x-xs-11-pro-2 screen">
        <div className="overlap-group">
          <Layer812 src={layer812Props.src} />
          <ScrollGroup1
            overlapGroup1={scrollGroup1Props.overlapGroup1}
            path10208={scrollGroup1Props.path10208}
            layer812Props={scrollGroup1Props.layer812Props}
            layer8122Props={scrollGroup1Props.layer8122Props}
          />
          <img className="ellipse-1" src={ellipse1} />
          <img className="path-10237" src={path10237} />
          <img className="path-10238" src={path10238} />
          <div className="more-screen"></div>
          <div className="rectangle-17330 border-1px-dove-gray"></div>
          <div className="sign-up-screen">
            <StatusBar2
              path2707={statusBar2Props.path2707}
              path2708={statusBar2Props.path2708}
              path2709={statusBar2Props.path2709}
              path2710={statusBar2Props.path2710}
              path2711={statusBar2Props.path2711}
              path2712={statusBar2Props.path2712}
              iconsProps={statusBar2Props.iconsProps}
            />
            <h1 className="title">{parcelInformation}</h1>
            <div className="text-2 metropolis-medium-concord-14px">{text19}</div>
            <TextField>{textFieldProps.children}</TextField>
            <TextField className="text-field">{textField2Props.children}</TextField>
            <div className="delivery-instructions">
              <div className="insurance">{insurance}</div>
              <div className="group-8115">
                <div className="group-8114">
                  <div className="overlap-group1">
                    <img className="line-90" src={line90} />
                    <img className="line-91" src={line91} />
                  </div>
                </div>
                <div className="add">{add}</div>
              </div>
            </div>
            <LoginButton>{loginButtonProps.children}</LoginButton>
            <div className="rectangle-183"></div>
          </div>
          <Group8129
            path2718={group8129Props.path2718}
            path10249={group8129Props.path10249}
            path10250={group8129Props.path10250}
            path2719={group8129Props.path2719}
          />
        </div>
      </div>
    </div>
  );
}


function Layer812(props) {
  const { src, className } = props;

  return (
    <div className={`layer812-2 ${className || ""}`}>
      <img className="path-4" src={src} />
    </div>
  );
}


function ScrollGroup1(props) {
  const { overlapGroup1, path10208, layer812Props, layer8122Props } = props;

  return (
    <div className="scroll-group-2">
      <div className="overlap-group1-1" style={{ backgroundImage: `url(${overlapGroup1})` }}>
        <div className="group-8097">
          <div className="overlap-group2">
            <div className="ellipse-80"></div>
            <div className="ellipse-81 border-2px-white"></div>
          </div>
        </div>
        <img className="path-10234" src={path10208} />
        <div className="ellipse-82"></div>
        <div className="ellipse-83"></div>
        <Layer812 src={layer812Props.src} className="layer812-1" />
        <Layer812 src={layer8122Props.src} className="layer812" />
      </div>
    </div>
  );
}


function StatusBar2(props) {
  const { path2707, path2708, path2709, path2710, path2711, path2712, iconsProps } = props;

  return (
    <div className="status-bar">
      <div className="time">
        <img className="path-2707" src={path2707} />
        <img className="path-2708" src={path2708} />
        <img className="path-2709" src={path2709} />
        <img className="path-2710" src={path2710} />
        <img className="path-2711" src={path2711} />
        <img className="path-2712" src={path2712} />
      </div>
      <Icons
        group865={iconsProps.group865}
        group863={iconsProps.group863}
        overlapGroup2={iconsProps.overlapGroup2}
        rectangle179={iconsProps.rectangle179}
        path2716={iconsProps.path2716}
      />
    </div>
  );
}


function Icons(props) {
  const { group865, group863, overlapGroup2, rectangle179, path2716 } = props;

  return (
    <div className="icons">
      <div className="group-865" style={{ backgroundImage: `url(${group865})` }}></div>
      <div className="group-863" style={{ backgroundImage: `url(${group863})` }}></div>
      <div className="group-868">
        <div className="overlap-group1-2" style={{ backgroundImage: `url(${overlapGroup2})` }}>
          <img className="rectangle-179" src={rectangle179} />
        </div>
        <img className="path-2716" src={path2716} />
      </div>
    </div>
  );
}


function TextField(props) {
  const { children, className } = props;

  return (
    <div className={`text-field-1 ${className || ""}`}>
      <div className="weight metropolis-regular-normal-pink-swan-14px">{children}</div>
    </div>
  );
}


function LoginButton(props) {
  const { children } = props;

  return (
    <div className="sign-up-button">
      <div className="order metropolis-bold-white-16px">{children}</div>
    </div>
  );
}


function Group8129(props) {
  const { path2718, path10249, path10250, path2719 } = props;

  return (
    <div className="group-8130 border-1px-dove-gray">
      <img className="path-2718" src={path2718} />
      <img className="path-" src={path10249} />
      <img className="path-" src={path10250} />
      <img className="path-" src={path2719} />
    </div>
  );
}

const layer812Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10209@1x.png",
};

const layer8122Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10209@1x.png",
};

const layer8123Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10209@1x.png",
};

const scrollGroup1Data = {
    overlapGroup1: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/image-5@1x.png",
    path10208: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10208@1x.png",
    layer812Props: layer8122Data,
    layer8122Props: layer8123Data,
};

const iconsData = {
    group865: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2714-10@1x.png",
    group863: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2713-10@1x.png",
    overlapGroup2: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2715-10@1x.png",
    rectangle179: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/rectangle-179-10@1x.png",
    path2716: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2716-10@1x.png",
};

const statusBar2Data = {
    path2707: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2707-10@1x.png",
    path2708: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2708-10@1x.png",
    path2709: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2709-10@1x.png",
    path2710: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2710-10@1x.png",
    path2711: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2711-10@1x.png",
    path2712: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2712-10@1x.png",
    iconsProps: iconsData,
};

const textFieldData = {
    children: "Weight",
};

const textField2Data = {
    children: "Parcel estimated value",
};

const loginButtonData = {
    children: "Order",
};

const group8129Data = {
    path2718: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10249-1@1x.png",
    path10249: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10249-1@1x.png",
    path10250: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10249-1@1x.png",
    path2719: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10249-1@1x.png",
};

const iPhoneXXS11Pro2Data = {
    ellipse1: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/ellipse-1-1@1x.png",
    path10237: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10211@1x.png",
    path10238: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10211@1x.png",
    parcelInformation: "Parcel Information",
    text19: "Add your Parcel details",
    insurance: "Insurance",
    line90: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/line-90@1x.png",
    line91: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/line-91@1x.png",
    add: "Add",
    layer812Props: layer812Data,
    scrollGroup1Props: scrollGroup1Data,
    statusBar2Props: statusBar2Data,
    textFieldProps: textFieldData,
    textField2Props: textField2Data,
    loginButtonProps: loginButtonData,
    group8129Props: group8129Data,
};

