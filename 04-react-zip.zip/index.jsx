import React from 'react';

function App() {
  return <X04 {...x04Data} />;
}

export default App;

function X04(props) {
  const {
    signUp2,
    text5,
    signUp22,
    spanText,
    spanText2,
    statusBarProps,
    textFieldProps,
    textField2Props,
    textField3Props,
    textField4Props,
    textField5Props,
    textField6Props,
  } = props;

  return (
    <div class="container-center-horizontal">
      <div className="x04 screen">
        <StatusBar
          path2707={statusBarProps.path2707}
          path2708={statusBarProps.path2708}
          path2709={statusBarProps.path2709}
          path2710={statusBarProps.path2710}
          path2711={statusBarProps.path2711}
          path2712={statusBarProps.path2712}
          iconsProps={statusBarProps.iconsProps}
        />
        <h1 className="title">{signUp2}</h1>
        <p className="text-2 metropolis-medium-concord-14px">{text5}</p>
        <TextField>{textFieldProps.children}</TextField>
        <TextField className="text-field-1">{textField2Props.children}</TextField>
        <TextField className="text-field-1">{textField3Props.children}</TextField>
        <TextField className="text-field-1">{textField4Props.children}</TextField>
        <TextField className="text-field-1">{textField5Props.children}</TextField>
        <TextField className="text-field-1">{textField6Props.children}</TextField>
        <div className="sign-up-button">
          <div className="sign-up metropolis-bold-white-16px">{signUp22}</div>
        </div>
        <p className="text-1 metropolis-bold-nile-blue-14px">
          <span className="span metropolis-medium-concord-14px">{spanText}</span>
          <span className="span metropolis-bold-nile-blue-14px-2">{spanText2}</span>
        </p>
        <div className="rectangle-183"></div>
      </div>
    </div>
  );
}


function StatusBar(props) {
  const { path2707, path2708, path2709, path2710, path2711, path2712, iconsProps } = props;

  return (
    <div className="status-bar">
      <div className="time">
        <img className="path-2707" src={path2707} />
        <img className="path-2708" src={path2708} />
        <img className="path-2709" src={path2709} />
        <img className="path-2710" src={path2710} />
        <img className="path-2711" src={path2711} />
        <img className="path-2712" src={path2712} />
      </div>
      <Icons
        group865={iconsProps.group865}
        group863={iconsProps.group863}
        overlapGroup2={iconsProps.overlapGroup2}
        rectangle179={iconsProps.rectangle179}
        path2716={iconsProps.path2716}
      />
    </div>
  );
}


function Icons(props) {
  const { group865, group863, overlapGroup2, rectangle179, path2716 } = props;

  return (
    <div className="icons">
      <div className="group-865" style={{ backgroundImage: `url(${group865})` }}></div>
      <div className="group-863" style={{ backgroundImage: `url(${group863})` }}></div>
      <div className="group-868">
        <div className="overlap-group" style={{ backgroundImage: `url(${overlapGroup2})` }}>
          <img className="rectangle-179" src={rectangle179} />
        </div>
        <img className="path-2716" src={path2716} />
      </div>
    </div>
  );
}


function TextField(props) {
  const { children, className } = props;

  return (
    <div className={`text-field ${className || ""}`}>
      <div className="place metropolis-regular-normal-pink-swan-14px">{children}</div>
    </div>
  );
}

const iconsData = {
    group865: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2714-10@1x.png",
    group863: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2713-10@1x.png",
    overlapGroup2: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2715-10@1x.png",
    rectangle179: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/rectangle-179-10@1x.png",
    path2716: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2716-10@1x.png",
};

const statusBarData = {
    path2707: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2707-10@1x.png",
    path2708: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2708-10@1x.png",
    path2709: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2709-10@1x.png",
    path2710: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2710-10@1x.png",
    path2711: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2711-1@1x.png",
    path2712: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2712-10@1x.png",
    iconsProps: iconsData,
};

const textFieldData = {
    children: "Name",
};

const textField2Data = {
    children: "Email",
};

const textField3Data = {
    children: "Mobile No",
};

const textField4Data = {
    children: "Address",
};

const textField5Data = {
    children: "Password",
};

const textField6Data = {
    children: "Confirm Password",
};

const x04Data = {
    signUp2: "Sign Up",
    text5: "Add your details to sign up",
    signUp22: "Sign Up",
    spanText: "Already have an Account? ",
    spanText2: "Login",
    statusBarProps: statusBarData,
    textFieldProps: textFieldData,
    textField2Props: textField2Data,
    textField3Props: textField3Data,
    textField4Props: textField4Data,
    textField5Props: textField5Data,
    textField6Props: textField6Data,
};

