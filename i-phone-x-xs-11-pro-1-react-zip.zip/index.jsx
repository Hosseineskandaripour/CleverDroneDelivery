import React from 'react';

function App() {
  return <IPhoneXXS11Pro1 {...iPhoneXXS11Pro1Data} />;
}

export default App;

function IPhoneXXS11Pro1(props) {
  const {
    ellipse1,
    path10211,
    path10233,
    check,
    xcontinue,
    scrollGroup1Props,
    group8134Props,
    moreScreenProps,
    group8129Props,
  } = props;

  return (
    <div class="container-center-horizontal">
      <div className="iphone-x-xs-11-pro-1 screen">
        <div className="overlap-group">
          <ScrollGroup1
            overlapGroup1={scrollGroup1Props.overlapGroup1}
            path10208={scrollGroup1Props.path10208}
            layer812Props={scrollGroup1Props.layer812Props}
            layer8122Props={scrollGroup1Props.layer8122Props}
          />
          <img className="ellipse-1" src={ellipse1} />
          <Group8134
            address={group8134Props.address}
            ilUsa={group8134Props.ilUsa}
            address2={group8134Props.address2}
            ilUsa2={group8134Props.ilUsa2}
          />
          <img className="path-10211" src={path10211} />
          <img className="path-10233" src={path10233} />
          <MoreScreen statusBar2Props={moreScreenProps.statusBar2Props} />
          <div className="group-8096">
            <img className="check" src={check} />
            <div className="continue">{xcontinue}</div>
          </div>
          <Group8129
            path2718={group8129Props.path2718}
            path10249={group8129Props.path10249}
            path10250={group8129Props.path10250}
            path2719={group8129Props.path2719}
          />
        </div>
      </div>
    </div>
  );
}


function ScrollGroup1(props) {
  const { overlapGroup1, path10208, layer812Props, layer8122Props } = props;

  return (
    <div className="scroll-group-1">
      <div className="overlap-group1" style={{ backgroundImage: `url(${overlapGroup1})` }}>
        <div className="group-8095">
          <div className="overlap-group2">
            <div className="ellipse-76"></div>
            <div className="ellipse-77 border-2px-white"></div>
          </div>
        </div>
        <img className="path-10208" src={path10208} />
        <div className="ellipse-78"></div>
        <div className="ellipse-79"></div>
        <Layer812 src={layer812Props.src} />
        <Layer812 src={layer8122Props.src} className="layer812-1" />
      </div>
    </div>
  );
}


function Layer812(props) {
  const { src, className } = props;

  return (
    <div className={`layer812 ${className || ""}`}>
      <img className="path-10209" src={src} />
    </div>
  );
}


function Group8134(props) {
  const { address, ilUsa, address2, ilUsa2 } = props;

  return (
    <div className="group-8134">
      <div className="overlap-group3">
        <div className="address helveticaneue-bold-white-17px">{address}</div>
        <div className="il-usa-1 helveticaneue-regular-normal-white-12px">{ilUsa}</div>
      </div>
      <div className="overlap-group4">
        <div className="address-1 helveticaneue-bold-white-17px">{address2}</div>
        <div className="il-usa helveticaneue-regular-normal-white-12px">{ilUsa2}</div>
      </div>
    </div>
  );
}


function MoreScreen(props) {
  const { statusBar2Props } = props;

  return (
    <div className="more-screen">
      <StatusBar2
        path2707={statusBar2Props.path2707}
        path2708={statusBar2Props.path2708}
        path2709={statusBar2Props.path2709}
        path2710={statusBar2Props.path2710}
        path2711={statusBar2Props.path2711}
        path2712={statusBar2Props.path2712}
        iconsProps={statusBar2Props.iconsProps}
      />
      <div className="rectangle-183"></div>
    </div>
  );
}


function StatusBar2(props) {
  const { path2707, path2708, path2709, path2710, path2711, path2712, iconsProps } = props;

  return (
    <div className="status-bar">
      <div className="time">
        <img className="path-2707" src={path2707} />
        <img className="path-2708" src={path2708} />
        <img className="path-2709" src={path2709} />
        <img className="path-2710" src={path2710} />
        <img className="path-2711" src={path2711} />
        <img className="path-2712" src={path2712} />
      </div>
      <Icons
        group865={iconsProps.group865}
        group863={iconsProps.group863}
        overlapGroup2={iconsProps.overlapGroup2}
        rectangle179={iconsProps.rectangle179}
        path2716={iconsProps.path2716}
      />
    </div>
  );
}


function Icons(props) {
  const { group865, group863, overlapGroup2, rectangle179, path2716 } = props;

  return (
    <div className="icons">
      <div className="group-865" style={{ backgroundImage: `url(${group865})` }}></div>
      <div className="group-863" style={{ backgroundImage: `url(${group863})` }}></div>
      <div className="group-868">
        <div className="overlap-group1-1" style={{ backgroundImage: `url(${overlapGroup2})` }}>
          <img className="rectangle-179" src={rectangle179} />
        </div>
        <img className="path-2716" src={path2716} />
      </div>
    </div>
  );
}


function Group8129(props) {
  const { path2718, path10249, path10250, path2719 } = props;

  return (
    <div className="group-8129 border-1px-dove-gray">
      <img className="path-2718" src={path2718} />
      <img className="path-" src={path10249} />
      <img className="path-" src={path10250} />
      <img className="path-" src={path2719} />
    </div>
  );
}

const layer812Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10209@1x.png",
};

const layer8122Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10209@1x.png",
};

const scrollGroup1Data = {
    overlapGroup1: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/image-5@1x.png",
    path10208: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10208@1x.png",
    layer812Props: layer812Data,
    layer8122Props: layer8122Data,
};

const group8134Data = {
    address: "915 W Marketview Dr, Champaign",
    ilUsa: "IL, USA",
    address2: "14 E Anthony Dr, Unit A, Champaign",
    ilUsa2: "IL, USA",
};

const iconsData = {
    group865: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2714-10@1x.png",
    group863: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2713-10@1x.png",
    overlapGroup2: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2715-10@1x.png",
    rectangle179: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/rectangle-179-10@1x.png",
    path2716: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2716-10@1x.png",
};

const statusBar2Data = {
    path2707: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2707-10@1x.png",
    path2708: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2708-10@1x.png",
    path2709: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2709-10@1x.png",
    path2710: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2710-10@1x.png",
    path2711: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2711-10@1x.png",
    path2712: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2712-10@1x.png",
    iconsProps: iconsData,
};

const moreScreenData = {
    statusBar2Props: statusBar2Data,
};

const group8129Data = {
    path2718: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10249-1@1x.png",
    path10249: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10249-1@1x.png",
    path10250: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10249-1@1x.png",
    path2719: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10249-1@1x.png",
};

const iPhoneXXS11Pro1Data = {
    ellipse1: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/ellipse-1-1@1x.png",
    path10211: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10211@1x.png",
    path10233: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-10211@1x.png",
    check: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/check@1x.png",
    xcontinue: "Continue",
    scrollGroup1Props: scrollGroup1Data,
    group8134Props: group8134Data,
    moreScreenProps: moreScreenData,
    group8129Props: group8129Data,
};

