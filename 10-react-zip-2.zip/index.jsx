import React from 'react';

function App() {
  return <X10 {...x10Data} />;
}

export default App;

function X10(props) {
  const {
    overlapGroup,
    image2,
    liveTracking2,
    liveTracking22,
    text16,
    text17,
    statusBar2Props,
    statusBar2Props2,
    sendButtonProps,
    sendButtonProps2,
  } = props;

  return (
    <div class="container-center-horizontal">
      <div className="x10 screen">
        <div className="overlap-group3">
          <StatusBar2
            path2707={statusBar2Props.path2707}
            path2708={statusBar2Props.path2708}
            path2709={statusBar2Props.path2709}
            path2710={statusBar2Props.path2710}
            path2711={statusBar2Props.path2711}
            path2712={statusBar2Props.path2712}
            iconsProps={statusBar2Props.iconsProps}
          />
          <StatusBar2
            path2707={statusBar2Props2.path2707}
            path2708={statusBar2Props2.path2708}
            path2709={statusBar2Props2.path2709}
            path2710={statusBar2Props2.path2710}
            path2711={statusBar2Props2.path2711}
            path2712={statusBar2Props2.path2712}
            iconsProps={statusBar2Props2.iconsProps}
          />
        </div>
        <div className="overlap-group" style={{ backgroundImage: `url(${overlapGroup})` }}>
          <img className="image-2" src={image2} />
        </div>
        <div className="overlap-group4">
          <SliderIndicators />
          <SliderIndicators />
        </div>
        <div className="overlap-group5">
          <h1 className="overlap-group5-item metropolis-extra-bold-gravel-28px">{liveTracking2}</h1>
          <div className="overlap-group5-item metropolis-extra-bold-gravel-28px">{liveTracking22}</div>
        </div>
        <div className="overlap-group1">
          <p className="text- metropolis-medium-concord-13px">{text16}</p>
          <p className="text- metropolis-medium-concord-13px">{text17}</p>
        </div>
        <div className="overlap-group2">
          <SendButton>{sendButtonProps.children}</SendButton>
          <SendButton>{sendButtonProps2.children}</SendButton>
        </div>
        <div className="overlap-group6">
          <div className="rectangle-17338"></div>
        </div>
      </div>
    </div>
  );
}


function StatusBar2(props) {
  const { path2707, path2708, path2709, path2710, path2711, path2712, iconsProps } = props;

  return (
    <div className="status-bar-1">
      <div className="time">
        <img className="path-2707" src={path2707} />
        <img className="path-2708" src={path2708} />
        <img className="path-2709" src={path2709} />
        <img className="path-2710" src={path2710} />
        <img className="path-2711" src={path2711} />
        <img className="path-2712" src={path2712} />
      </div>
      <Icons
        group865={iconsProps.group865}
        group863={iconsProps.group863}
        overlapGroup2={iconsProps.overlapGroup2}
        rectangle179={iconsProps.rectangle179}
        path2716={iconsProps.path2716}
      />
    </div>
  );
}


function Icons(props) {
  const { group865, group863, overlapGroup2, rectangle179, path2716, className } = props;

  return (
    <div className={`icons ${className || ""}`}>
      <div className="group-865" style={{ backgroundImage: `url(${group865})` }}></div>
      <div className="group-863" style={{ backgroundImage: `url(${group863})` }}></div>
      <div className="group-868">
        <div className="overlap-group7" style={{ backgroundImage: `url(${overlapGroup2})` }}>
          <img className="rectangle-179" src={rectangle179} />
        </div>
        <img className="path-2716" src={path2716} />
      </div>
    </div>
  );
}


function SliderIndicators() {
  return (
    <div className="slider-indicators-1">
      <div className="ellipse-1"></div>
      <div className="ellipse-2"></div>
      <div className="ellipse-3"></div>
    </div>
  );
}


function SendButton(props) {
  const { children } = props;

  return (
    <div className="send-button-1">
      <div className="next metropolis-bold-white-16px">{children}</div>
    </div>
  );
}

const iconsData = {
    group865: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2714-10@1x.png",
    group863: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2713-10@1x.png",
    overlapGroup2: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2715-10@1x.png",
    rectangle179: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/rectangle-179-10@1x.png",
    path2716: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2716-10@1x.png",
};

const statusBar2Data = {
    path2707: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2707-10@1x.png",
    path2708: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2708-10@1x.png",
    path2709: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2709-10@1x.png",
    path2710: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2710-10@1x.png",
    path2711: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2711-10@1x.png",
    path2712: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2712-10@1x.png",
    iconsProps: iconsData,
};

const icons2Data = {
    group865: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2714-10@1x.png",
    group863: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2713-10@1x.png",
    overlapGroup2: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2715-10@1x.png",
    rectangle179: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/rectangle-179-10@1x.png",
    path2716: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2716-10@1x.png",
};

const statusBar22Data = {
    path2707: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2707-10@1x.png",
    path2708: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2708-10@1x.png",
    path2709: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2709-10@1x.png",
    path2710: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2710-10@1x.png",
    path2711: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2711-10@1x.png",
    path2712: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2712-10@1x.png",
    iconsProps: icons2Data,
};

const sendButtonData = {
    children: "Next",
};

const sendButton2Data = {
    children: "Next",
};

const x10Data = {
    overlapGroup: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/image-2-1@1x.png",
    image2: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/image-2-1@1x.png",
    liveTracking2: "Live Tracking",
    liveTracking22: "Live Tracking",
    text16: "Real time tracking of your parcel on the app once you placed the order",
    text17: "Real time tracking of your parcel on the app once you placed the order",
    statusBar2Props: statusBar2Data,
    statusBar2Props2: statusBar22Data,
    sendButtonProps: sendButtonData,
    sendButtonProps2: sendButton2Data,
};

