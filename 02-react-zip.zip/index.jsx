import React from 'react';

function App() {
  return <X02 {...x02Data} />;
}

export default App;

function X02(props) {
  const {
    organeTopShape,
    image1,
    place,
    drone,
    delivery,
    deliverEverything,
    login,
    createAnAccount,
    statusBarProps,
  } = props;

  return (
    <div class="container-center-horizontal">
      <div className="x02 screen">
        <div className="overlap-group1">
          <div className="organe-top-shape" style={{ backgroundImage: `url(${organeTopShape})` }}></div>
          <StatusBar
            path2707={statusBarProps.path2707}
            path2708={statusBarProps.path2708}
            path2709={statusBarProps.path2709}
            path2710={statusBarProps.path2710}
            path2711={statusBarProps.path2711}
            path2712={statusBarProps.path2712}
            iconsProps={statusBarProps.iconsProps}
          />
          <img className="image-1" src={image1} />
        </div>
        <div className="overlap-group">
          <div className="meal-monkey-text">
            <h1 className="place">{place}</h1>
            <div className="drone">{drone}</div>
          </div>
          <div className="delivery">{delivery}</div>
        </div>
        <div className="deliver-everything metropolis-medium-concord-13px">{deliverEverything}</div>
        <div className="login-button">
          <div className="login metropolis-bold-white-16px">{login}</div>
        </div>
        <div className="create-an-account-button">
          <div className="create-an-account">{createAnAccount}</div>
        </div>
        <div className="rectangle-183"></div>
      </div>
    </div>
  );
}


function StatusBar(props) {
  const { path2707, path2708, path2709, path2710, path2711, path2712, iconsProps } = props;

  return (
    <div className="status-bar">
      <div className="time">
        <img className="path-2707" src={path2707} />
        <img className="path-2708" src={path2708} />
        <img className="path-2709" src={path2709} />
        <img className="path-2710" src={path2710} />
        <img className="path-2711" src={path2711} />
        <img className="path-2712" src={path2712} />
      </div>
      <Icons
        group865={iconsProps.group865}
        group863={iconsProps.group863}
        overlapGroup2={iconsProps.overlapGroup2}
        rectangle179={iconsProps.rectangle179}
        path2716={iconsProps.path2716}
      />
    </div>
  );
}


function Icons(props) {
  const { group865, group863, overlapGroup2, rectangle179, path2716 } = props;

  return (
    <div className="icons">
      <div className="group-865" style={{ backgroundImage: `url(${group865})` }}></div>
      <div className="group-863" style={{ backgroundImage: `url(${group863})` }}></div>
      <div className="group-868">
        <div className="overlap-group2" style={{ backgroundImage: `url(${overlapGroup2})` }}>
          <img className="rectangle-179" src={rectangle179} />
        </div>
        <img className="path-2716" src={path2716} />
      </div>
    </div>
  );
}

const iconsData = {
    group865: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2714@1x.png",
    group863: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2713@1x.png",
    overlapGroup2: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2715@1x.png",
    rectangle179: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/rectangle-179@1x.png",
    path2716: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2716@1x.png",
};

const statusBarData = {
    path2707: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2707@1x.png",
    path2708: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2708@1x.png",
    path2709: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2709@1x.png",
    path2710: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2710@1x.png",
    path2711: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2711@1x.png",
    path2712: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2712@1x.png",
    iconsProps: iconsData,
};

const x02Data = {
    organeTopShape: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/shaped-subtraction@1x.png",
    image1: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/image-1@1x.png",
    place: "Clever",
    drone: "Drone",
    delivery: "DELIVERY",
    deliverEverything: "Deliver Everything",
    login: "Login",
    createAnAccount: "Create an Account",
    statusBarProps: statusBarData,
};

