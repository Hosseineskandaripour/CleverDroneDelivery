import React from 'react';

function App() {
  return (
    <X05
      resetPassword="Reset Password"
      text7={
        <>
          Please enter your email to receive a <br />
          link to create a new password via email
        </>
      }
      place="Send"
      statusBarProps={x05Data.statusBarProps}
      textFieldProps={x05Data.textFieldProps}
    />
  );
}

export default App;

function X05(props) {
  const { resetPassword, text7, place, statusBarProps, textFieldProps } = props;

  return (
    <div class="container-center-horizontal">
      <div className="x05 screen">
        <StatusBar
          path2707={statusBarProps.path2707}
          path2708={statusBarProps.path2708}
          path2709={statusBarProps.path2709}
          path2710={statusBarProps.path2710}
          path2711={statusBarProps.path2711}
          path2712={statusBarProps.path2712}
          iconsProps={statusBarProps.iconsProps}
        />
        <h1 className="title">{resetPassword}</h1>
        <p className="text-1 metropolis-medium-concord-14px">{text7}</p>
        <TextField>{textFieldProps.children}</TextField>
        <div className="send-button">
          <div className="place metropolis-bold-white-16px">{place}</div>
        </div>
        <div className="rectangle-183"></div>
      </div>
    </div>
  );
}


function StatusBar(props) {
  const { path2707, path2708, path2709, path2710, path2711, path2712, iconsProps } = props;

  return (
    <div className="status-bar">
      <div className="time">
        <img className="path-2707" src={path2707} />
        <img className="path-2708" src={path2708} />
        <img className="path-2709" src={path2709} />
        <img className="path-2710" src={path2710} />
        <img className="path-2711" src={path2711} />
        <img className="path-2712" src={path2712} />
      </div>
      <Icons
        group865={iconsProps.group865}
        group863={iconsProps.group863}
        overlapGroup2={iconsProps.overlapGroup2}
        rectangle179={iconsProps.rectangle179}
        path2716={iconsProps.path2716}
      />
    </div>
  );
}


function Icons(props) {
  const { group865, group863, overlapGroup2, rectangle179, path2716 } = props;

  return (
    <div className="icons">
      <div className="group-865" style={{ backgroundImage: `url(${group865})` }}></div>
      <div className="group-863" style={{ backgroundImage: `url(${group863})` }}></div>
      <div className="group-868">
        <div className="overlap-group" style={{ backgroundImage: `url(${overlapGroup2})` }}>
          <img className="rectangle-179" src={rectangle179} />
        </div>
        <img className="path-2716" src={path2716} />
      </div>
    </div>
  );
}


function TextField(props) {
  const { children } = props;

  return (
    <div className="text-field">
      <div className="email metropolis-regular-normal-pink-swan-14px">{children}</div>
    </div>
  );
}

const iconsData = {
    group865: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2714-10@1x.png",
    group863: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2713-10@1x.png",
    overlapGroup2: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2715-10@1x.png",
    rectangle179: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/rectangle-179-10@1x.png",
    path2716: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2716-10@1x.png",
};

const statusBarData = {
    path2707: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2707-10@1x.png",
    path2708: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2708-10@1x.png",
    path2709: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2709-10@1x.png",
    path2710: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2710-10@1x.png",
    path2711: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2711-1@1x.png",
    path2712: "https://anima-uploads.s3.amazonaws.com/projects/60be930687c891ee9c05e846/releases/60be9bccfb9e594b489c6e72/img/path-2712-10@1x.png",
    iconsProps: iconsData,
};

const textFieldData = {
    children: "Email",
};

const x05Data = {
    statusBarProps: statusBarData,
    textFieldProps: textFieldData,
};

